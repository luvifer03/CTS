package alt;

public class AlternateNumbersDifference {

}
